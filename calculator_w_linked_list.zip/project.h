#ifndef INT_LINKED_LIST
#define INT_LINKED_LIST
#include <string> 
using namespace std;
class Node{
	public:
		Node() {
        next = 0;
    }
    Node(int x, Node *ptr = 0) {
        data = x; next = ptr;
    }
    int data;
    Node *next;
};

class project{
	public:
		project(){
			head_array[100];
			
			for(int i=0; i<100; i++)
			{
				head_array[i]=NULL;
			}
		}
		void addToHead(int x,int y);
		int reverseTheList(int x);
		bool IsEmpty(int);
		int UpdateBigInt();
		Node make_empty_list(int size);
		void freeBigInt();
		Node get_head_array(int x);
		Node addBigInt(int x, int y, int goal);
		Node Multiply(int x, int y, int goal);
		void print_all(int);
		Node CreateBigInt(string tokens,int x);
		Node writeFile(int x);
		
	private:
		Node *head_array[100];
};

#endif
