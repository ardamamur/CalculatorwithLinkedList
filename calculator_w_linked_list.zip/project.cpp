#include <iostream>
#include "project.h"
#include <cstdlib>
#include <list>
#include <string> 
#include <fstream>
#include <bits/stdc++.h>
using namespace std;


void project::addToHead(int x,int y)
{
	Node *temp=head_array[y];
	Node *add=new Node;
	add->data=x;
	add->next=head_array[y];
	head_array[y]=add;
}
Node project::get_head_array(int x)
{
	return *head_array[x];
}

bool project::IsEmpty(int x)
{
	if(head_array[x]->next==NULL)
		return true;
	else
		return false;
		
}

int project::reverseTheList(int k)
{
	Node *current=head_array[k];
	Node *temp,*prev=NULL;
	int len=0;
	
	while(current!=NULL)
	{
		temp=current->next;
		current->next=prev;
		prev=current;
		current=temp;
		len++;
	}
	head_array[k]=prev;
	return len;
		
}	
Node project::CreateBigInt(string tokens,int x)
{
	
	
	int i=0;
	int number[250];
	
	for(i=0; i<tokens.size(); i++)
		number[i]=tokens[i]-'0';
	
	for(int k=tokens.size()-1; k>=0; k--)
	{
		addToHead(number[k],x);
	}
	//print_all(x);

	
}

Node project::addBigInt(int x, int y, int goal)
{
	
	
	
	Node *result= new Node;
	result=NULL;
	Node *temp=NULL;
	Node *prev=NULL;
	int carry=0;
	int sum=0;
	int len1=0;
	int len2=0;
	len1=reverseTheList(x);
	len2=reverseTheList(y);
	int diff=0;
	if(len1>len2)
	{
		diff=len1-len2;
		reverseTheList(y);
		while(diff>0)
		{
			addToHead(0,y);
			diff--;
		}
		reverseTheList(y);
		
	}
	else if(len2>len1)
	{
		diff=len2-len1;
		reverseTheList(x);
		while(diff>0)
		{
			addToHead(0,x);
			diff--;
		}
		reverseTheList(x);
		
	}

	while(head_array[x]!=NULL || head_array[y]!=NULL)
	{
	
		sum=carry+(head_array[x]->data)+(head_array[y]->data);
		
		if(sum>=10)
			carry=1;	
		else
			carry=0;
		
		sum=sum%10;
	
		temp=new Node;
		temp->data=sum;
		temp->next=NULL;
		
		if(result==NULL)
			result=temp;
		
		else
			prev->next=temp;
		
		prev=temp;
	
		head_array[x]=head_array[x]->next;
		head_array[y]=head_array[y]->next;	
	
	}	

	if (carry==1)
	{
	
		Node *carry_node=new Node;
		carry_node->data=1;
		carry_node->next=NULL;
		temp->next=carry_node;

	}

	reverseTheList(x);
	reverseTheList(y);

	Node *current=result;
	Node *temp_r=NULL;
	Node *prev_r=NULL;

	while(current!=NULL)
	{
		temp_r=current->next;
		current->next=prev_r;
		prev_r=current;
		current=temp_r;
		
	}
	result=prev_r;

	Node *print=result;
	/*while(print!=NULL)
	{
		cout<<print->data;
		print=print->next;
		
	}
	*/
//	return *result;
	head_array[goal]=result;
	
}


Node project::Multiply(int x, int y, int goal)
{
	int len1=reverseTheList(x);
	int len2=reverseTheList(y);
	
	Node *result=new Node();
	Node *temp=result;
	
	int i=0;
	while(i<len1+len2+1)//make a empty_list with max size can be ;
	{	
	
		Node *add=new Node();
		add->data=0;
		add->next=result;
		result=add;
		i++;
	}


	Node *second=head_array[y];
	Node *result_ptr1=result;
	Node *result_ptr2=result;
	Node *first=head_array[x];

	while(second!=NULL)
	{

		int carry=0;
		result_ptr2 = result_ptr1;
       	first=head_array[x];
		int i=0;
		while (first!=NULL)
		{
		
			int multiply=0;
			multiply=(first->data*second->data)+carry;
			result_ptr2->data = result_ptr2->data + multiply%10;
			carry = multiply/10 + result_ptr2->data/10; 
        	result_ptr2->data = result_ptr2->data%10; 
		
			first=first->next; 
            result_ptr2 = result_ptr2->next;
            
  		
  			
    	}
    	
    	if (carry > 0) 
		{ 
           	result_ptr2->data += carry; 
        }
		
		result_ptr1 = result_ptr1->next; 
        second=second->next; 
	}
	
	reverseTheList(x);
	reverseTheList(y);
	//reverse code for the result list;
	Node *curr=result;
	Node *prev=NULL;
	Node *temp_n=NULL;
	while(curr!=NULL)
	{
		temp_n=curr->next;
		curr->next=prev;
		prev=curr;
		curr=temp_n;
		
	}
	result=prev;

	Node *del=result->next;
	int flag=1;
	while(flag)
	{
		Node *temp_del=del;
		if(del->data!=0)
			flag=0;
		else
		{
			result=del->next;
			del=del->next;
			free(temp_del);
		}
			
	}
    
    Node *print=result;
	/*while(print!=NULL)
	{
		cout<<print->data<<" ";
		print=print->next;
		
	}
	*/
	head_array[goal]=result;

}
int project::UpdateBigInt(){
	
		
	string line;
	ifstream term_project;
	term_project.open("input.txt");
	getline(term_project,line);
	cout<<line<<endl;
	
	vector <string> tokens; 
    stringstream check1(line);     
    string intermediate; 
    while(getline(check1, intermediate, ' ')) 
    { 
        tokens.push_back(intermediate); 
    }
	int count_numbers=0; 

    for(int i = 0; i < tokens.size(); i++) 
    { 
	    //cout << tokens[i] << '\n'; 
	    count_numbers++;
	}
	
	//erorr cases
	int q=0;
	if(tokens[q][0]=='+'|| tokens[q][0]=='*')
	{
		cout<<"ERROR(invalid input)";
		return 1;
	}
	else
	{
		q++;
		while(q<tokens.size())
		{
			if(tokens[q][0]=='+'|| tokens[q][0]=='*')
			{
				if(tokens[q+1][0]=='+'|| tokens[q+1][0]=='*')
				{
					cout<<"ERROR(invalid input)";
					return 1;
				}
						
			}
			q++;
	
		}
	
	
	}
	
    string line_array[10];
   	int count=0;
	for(int j=0; j<count_numbers; j++)
	{
		if(tokens[j][0]!='*' && tokens[j][0]!='+')
		{
			line_array[count]=tokens[j];
			CreateBigInt(line_array[count],count);
			count++;
		}
	}
	
	count=count+1;
	int count_array[10];
	int add_array[10]={0,0,0,0,0,0,0,0,0,0};
	int a=0;
	int k=0;
	int z=0;
	int enough=0;
	int check_mul=1;
	
	while(k<tokens.size() && enough==0)
	{
	

		if(tokens[k][0]=='*' && k<tokens.size())
		{
			Multiply((k-1)/2,(k+1)/2, count);
			k++;
			z=k-1;
			while(z<tokens.size())
			{
				if(tokens[z][0]=='+')	
					check_mul=0;
				z=z+2;
			}
			if(check_mul==1)
			{
				int y=k-1;
				y=y+2;
				while(y<tokens.size())
				{
					Multiply(count,(y+1)/2,count);
					y=y+2;
				}
				count_array[a]=count;
				add_array[a]=count_array[a];
				count++;
				a++;
				
				enough=1;
				
				
			}	
			
			else if(check_mul==0)
			{	
				while(tokens[k][0]!='+' && k<tokens.size())
				{
			
					if(tokens[k][0]=='*')
					{
						Multiply(count,(k+1)/2,count);
					}
					k=k+1;
				}	
			}
			count_array[a]=count;
			add_array[a]=count_array[a];
			count++;
			a++;
			
			
		}
		k=k+1;
	}

	
	int l=0;
	int aim=0;

	
	if (tokens[1][0]=='+') //check is the first operation is addition
	{
		add_array[a]=0;
		a++;
	}

	
	if(tokens[tokens.size()-2][0]=='+') //check is the last operation is addition
	{
		add_array[a]=tokens.size()/2;
		a++;
	}

	l=l+2;
	int size=tokens.size()-2;
	while(l<size)
	{
		if(tokens[l+1][0]=='+')
		{
			if(tokens[l+2][0]=='*')
			{
				l=l+1;
				while(tokens[l][0]!='+')
				{
					l=l+1;
				}			
			}
			
			add_array[a]=(l+1)/2;
			//print_all(add_array[a]);
			a++;	
				
		}
		l++;
		
	}
	
	int finish=0;
	
	while(finish<a-1)
	{
		addBigInt(add_array[finish],add_array[finish+1],count);
		finish=finish+2;
		while(finish<a-1)
		{
			addBigInt(count,add_array[finish],count);
			finish=finish+1;
		
		}	
		
	}
	//in any case the function will not add secondlast num when the program just do addition:
	
	int yikik=1;
	int bit=0;
	int done=0;
	int cse=1;
	int data=0;
	while(cse<tokens.size() && done!=1)
	{
		if(tokens[cse][0]=='*')
		{
			data=cse;
			while(data<tokens.size())
			{
				if(tokens[data][0]=='+')
					done=1;
				data=data+2;
			}
		}
		cse=cse+2;
	}
	if(done==0)
	{
		addBigInt(count,add_array[a-1],count);
		
	}
	while(yikik<tokens.size() && bit!=1)
	{
		if(tokens[yikik][0]=='*')
			bit=1;
		yikik=yikik+2;
	}
	if(bit==0)
	{
		addBigInt(count,add_array[a-1],count);
	}
	
	cout<<"the result is:";
	print_all(count);
	
	//writeFile(count);
	
	

	
}
Node project::writeFile(int x)
{
	Node *p=head_array[x];
	FILE *pFile;
	pFile = fopen ("C:\\Users\tosh\Desktop\C\C++\Data_Structure\term_project\output.txt","wb");
    while(p)
    {
        if (pFile!=NULL)
        {
            fwrite(p,sizeof(Node),1,pFile);
            fclose (pFile);
        }
        p=p->next;
    }
}

void project::print_all(int x)
{
	Node *temp= head_array[x];
	while(temp!=NULL)
	{
		cout<<temp->data;
		temp=temp->next;
	}
	cout<<endl;
}


int main()
{
	project ptr,ptr2;
	
	ptr.UpdateBigInt();
	
	return 0;

}
